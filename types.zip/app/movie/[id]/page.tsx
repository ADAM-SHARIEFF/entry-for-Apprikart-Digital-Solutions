import { getMovieDetails } from "@/lib/api"
import { formatDate, formatRuntime } from "@/lib/utils"
import Image from "next/image"
import { Star } from "lucide-react"
import FavoriteButton from "@/components/favorite-button"
import MovieCast from "@/components/movie-cast"
import SimilarMovies from "@/components/similar-movies"

export default async function MoviePage({ params }: { params: { id: string } }) {
  const movie = await getMovieDetails(params.id)

  if (!movie) {
    return <div className="container mx-auto px-4 py-8">Movie not found</div>
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="relative">
        {movie.backdrop_path && (
          <div className="absolute inset-0 -z-10 h-[500px] w-full">
            <div className="relative h-full w-full">
              <Image
                src={`https://image.tmdb.org/t/p/original${movie.backdrop_path}`}
                alt={movie.title}
                fill
                className="object-cover opacity-20"
                priority
              />
              <div className="absolute inset-0 bg-gradient-to-b from-transparent to-background" />
            </div>
          </div>
        )}

        <div className="pt-8 md:pt-16 lg:pt-24">
          <div className="grid grid-cols-1 md:grid-cols-[300px_1fr] gap-8">
            <div className="relative aspect-[2/3] w-full max-w-[300px] mx-auto md:mx-0 overflow-hidden rounded-lg shadow-lg">
              {movie.poster_path ? (
                <Image
                  src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
                  alt={movie.title}
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, 300px"
                  priority
                />
              ) : (
                <div className="w-full h-full bg-muted flex items-center justify-center">No poster available</div>
              )}
            </div>

            <div>
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <h1 className="text-3xl md:text-4xl font-bold">{movie.title}</h1>
                  {movie.release_date && (
                    <p className="text-muted-foreground">
                      {formatDate(movie.release_date)}
                      {movie.runtime ? ` • ${formatRuntime(movie.runtime)}` : ""}
                    </p>
                  )}
                </div>
                <div className="flex items-center gap-4">
                  {movie.vote_average > 0 && (
                    <div className="flex items-center gap-1">
                      <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                      <span className="font-medium">{movie.vote_average.toFixed(1)}</span>
                    </div>
                  )}
                  <FavoriteButton movie={movie} />
                </div>
              </div>

              {movie.genres && movie.genres.length > 0 && (
                <div className="flex flex-wrap gap-2 my-4">
                  {movie.genres.map((genre) => (
                    <span key={genre.id} className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">
                      {genre.name}
                    </span>
                  ))}
                </div>
              )}

              {movie.tagline && <p className="italic text-muted-foreground mt-4">{movie.tagline}</p>}

              {movie.overview && (
                <div className="mt-6">
                  <h2 className="text-xl font-semibold mb-2">Overview</h2>
                  <p className="text-muted-foreground">{movie.overview}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <MovieCast movieId={params.id} />
      <SimilarMovies movieId={params.id} />
    </div>
  )
}

